//
//  Quote.swift
//  QuoteList
//
//  Created by Магомед on 26.03.2021.
//

import Foundation

class Author {
    var name: String
    var quotes: [String]
    
    init(name: String = "", quotes: String...) {
        self.name = name
        self.quotes = quotes
    }
}

class Quote {
    var text: String
    var author: String
    
    init(text: String, author: String = "Неизвестный автор") {
        self.text = text
        self.author = author
    }
}

class DataManager {
    
    static let shared = DataManager()
    
    private var quotes: [Quote] = [
        .init(text: "Чтобы двигать познание вперёд, теория должна поначалу быть контринтуитивной", author: "Дэниел Деннет"),
        .init(text: "Никогда не спорьте с идиотами. Вы опуститесь до их уровня, где они вас задавят своим опытом", author: "Марк Твен"),
        .init(text: "Правду следует подавать так, как подают пальто, а не швырять в лицо, как мокрое полотенце", author: "Марк Твен"),
        .init(text: "Лучше хранить молчание до тех пор, пока не спросят, чем говорить до тех пор, пока не попросят замолчать", author: "Али ибн Абу Талиб"),
    ]
    
    private init() { }
    
    func getAuthors() -> [String] {
        return Array(Set(quotes.map { $0.author }))
    }
    func getQuotes(for author: String) -> [String] {
        
        return []
    }
    
}
