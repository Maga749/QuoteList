//
//  AuthorListViewController.swift
//  QuoteList
//
//  Created by Магомед on 27.03.2021.
//

import UIKit

protocol AuthorListViewControllerDelegate: class {
    func AuthorListViewController(_ controller: AuthorListViewController, didFinishWith author: String)
    func AuthorListViewControllerDidCancel(_ controller: AuthorListViewController)
}

// TODO - prohibit using author name "Автор неизвестен"

class AuthorListViewController: UIViewController {
    
    private let randomAuthors = ["Аристотель", "Иммануил Кант", "Платон", "Конфуций", "Дэвид Юм", "Рене Декарт", "Сократ", "Никколо Макиавелли", "Джон Локк", "Диоген"]
    
    weak var delegate: AuthorListViewControllerDelegate?
    
    // MARK: - TABLEVIEW
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .insetGrouped)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    
    
    // MARK: - LIFECYCLE
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViewController()
    }
    
    // MARK: - VIEW CONTROLLER'S SETUP
    
    private func setupViewController() {
        view.backgroundColor = .systemBackground
        setupLayout()
        setupNavigationItem()
    }
    private func setupNavigationItem() {
        navigationItem.title = "Авторы"
        navigationItem.largeTitleDisplayMode = .never
    }
    private func setupLayout() {
        view.addSubview(tableView)
        
        let safeArea = view.safeAreaLayoutGuide
        
        tableView.anchor(top: safeArea.topAnchor,
                         leading: safeArea.leadingAnchor,
                         bottom: safeArea.bottomAnchor,
                         trailing: safeArea.trailingAnchor)
    }
}


extension AuthorListViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 2
        } else {
            return 10
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            cell.textLabel?.text = "Добавить автора"
            cell.textLabel?.textColor = .systemBlue
            cell.imageView?.image = UIImage(systemName: "plus.circle")
            cell.imageView?.tintColor = .systemBlue
        case (0, 1):
            cell.textLabel?.text = "Автор неизвестен"
            cell.textLabel?.textColor = .systemBlue
            cell.imageView?.image = UIImage(systemName: "questionmark.circle")
            cell.imageView?.tintColor = .systemBlue
        case (1, _):
            cell.textLabel?.text = randomAuthors[indexPath.row]
        default:
            fatalError()
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 1 {
            return "Добавленные авторы"
        } else {
            return nil
        }
    }
}


// MARK: - TABLEVIEW'S DELEGATE

extension AuthorListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch (indexPath.section, indexPath.row) {
        case (0, 0):
            showAddAlert()
        case (0, 1):
            delegate?.AuthorListViewController(self, didFinishWith: "Автор неизвестен")
        case (1, _):
            delegate?.AuthorListViewController(self, didFinishWith: randomAuthors[indexPath.row])
        default:
            fatalError()
        }
    }
}

// MARK: - HELPER METHODS

extension AuthorListViewController {
    private func showAddAlert() {
        let alert = UIAlertController(title: "Добавление автора",
                                      message: nil,
                                      preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Отменить",
                                         style: .cancel,
                                         handler: nil)
        let addAction = UIAlertAction(title: "Добавить",
                                      style: .default) { (alertAction) in
            let author = alert.textFields!.first!.text!
            self.delegate?.AuthorListViewController(self, didFinishWith: author)
        }
        addAction.isEnabled = false
        
        alert.addTextField { (textField) in
            textField.placeholder = "Введите имя автора..."
            NotificationCenter.default.addObserver(forName: UITextField.textDidChangeNotification, object: textField, queue: .main) { (notification) in
                addAction.isEnabled = !(alert.textFields?.first?.text?.isEmpty ?? false)
            }
        }
        
        alert.addAction(cancelAction)
        alert.addAction(addAction)
        
        // TODO - fill completion block
        present(alert, animated: true)
    }
}
