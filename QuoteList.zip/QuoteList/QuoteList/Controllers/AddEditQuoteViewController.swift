//
//  AddEditQuoteViewController.swift
//  Quotes
//
//  Created by Магомед on 24.03.2021.
//

import UIKit

protocol AddEditQuoteViewControllerDelegate: class {
    // TODO - finish with (author: String? = nil, quote: String)
    func addEditQuoteViewController(_ controller: AddEditQuoteViewController, didFinishWith quote: Quote, openingMode: AddEditQuoteViewController.OpeningMode)
    func addEditQuoteViewControllerDidCancel(_ controller: AddEditQuoteViewController)
}

class AddEditQuoteViewController: UIViewController {
    
    private var openingMode: OpeningMode
    weak var delegate: AddEditQuoteViewControllerDelegate?
    
    // MARK: - INTERFACE'S ELEMENTS
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .insetGrouped)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    
    lazy var doneButton = UIBarButtonItem(title: "Готово", style: .done, target: self, action: #selector(doneButtonPressed))
    lazy var cancelButton = UIBarButtonItem(title: "Отменить", style: .plain, target: self, action: #selector(doneButtonPressed))
    
    
    // MARK: - CELL'S VIEWS
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.backgroundColor = .clear
        textView.font = UIFont.preferredFont(forTextStyle: .body)
        textView.delegate = self
        return textView
    }()
    
    
    // MARK: - INITIALIZATION
    // TODO - add as parameter quote. If it is not nil, set mode to edit, else to add
    init(openingMode: OpeningMode) {
        self.openingMode = openingMode
        
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    // MARK: - LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
    
        setupViewController()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let selectedIndexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: selectedIndexPath, animated: true)
        }
    }
    
    
    // MARK: - VIEW CONTROLLER'S SETUP
    private func setupViewController() {
        view.backgroundColor = .systemBackground
        setupNavigationItem()
        setupLayout()
    }
    private func setupNavigationItem() {
        navigationItem.title = openingMode == .add ? "Добавить" : "Редактировать"
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = doneButton
        navigationItem.leftBarButtonItem = cancelButton
        navigationItem.backButtonTitle = ""
    }
    private func setupLayout() {
        view.addSubview(tableView)
        
        let safeArea = view.safeAreaLayoutGuide
        
        tableView.anchor(top: safeArea.topAnchor,
                         leading: safeArea.leadingAnchor,
                         bottom: safeArea.bottomAnchor,
                         trailing: safeArea.trailingAnchor)
    }
    
    // MARK: - ACTIONS
    @objc func quoteTextFieldChanged(_ textField: UITextField) {
        
    }
    @objc func authorTextFieldChanged(_ textField: UITextField) {
        
    }
    @objc func doneButtonPressed() {
//        let newQuote = Quote(entity: Quote.entity(), insertInto: nil)
//        newQuote.text = quoteTextField.text
//        newQuote.author = authorTextField.text
//        delegate?.addEditQuoteViewController(self, didFinishWith: newQuote, openingMode: openingMode)
    }
    @objc func cancelButtonPressed() {
        delegate?.addEditQuoteViewControllerDidCancel(self)
    }
}

extension AddEditQuoteViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        // TODO
    }
}


// MARK: - tableView's dataSource
extension AddEditQuoteViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        
        switch (indexPath.section, indexPath.row) {
        case (0, _):
            cell = UITableViewCell()
            cell.contentView.addSubview(textView)
            textView.fillSuperviewAccordingToMargins()
        case (1, _):
            cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            cell.textLabel?.text = "Автор"
            cell.detailTextLabel?.text = "Выбрать"
            cell.accessoryType = .disclosureIndicator
        default:
            fatalError()
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Цитата"
        } else {
            return nil
        }
    }
}


// MARK: - tableView's delegate
extension AddEditQuoteViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 120
        } else {
            return 44
        }
    }
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        return indexPath.section == 0 ? nil : indexPath
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        show(AuthorListViewController(), sender: nil)
    }
}


// MARK: - Supporting enum
extension AddEditQuoteViewController {
    enum OpeningMode {
        case add
        case edit
    }
}
