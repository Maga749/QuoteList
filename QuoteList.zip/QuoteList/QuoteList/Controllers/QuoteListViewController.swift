//
//  QuoteListViewController.swift
//  QuoteList
//
//  Created by Магомед on 26.03.2021.
//

import UIKit

class QuoteListViewController: UIViewController {
    
    // MARK: - DATA
    
    var quotes: [Quote] = [
        .init(text: "Чтобы двигать познание вперёд, теория должна поначалу быть контринтуитивной", author: "Дэниел Деннет"),
        .init(text: "Никогда не спорьте с идиотами. Вы опуститесь до их уровня, где они вас задавят своим опытом", author: "Марк Твен"),
        .init(text: "Правду следует подавать так, как подают пальто, а не швырять в лицо, как мокрое полотенце", author: "Марк Твен"),
        .init(text: "Лучше хранить молчание до тех пор, пока не спросят, чем говорить до тех пор, пока не попросят замолчать", author: "Али ибн Абу Талиб"),
    ]
    
    // MARK: - INTERFACE'S ELEMENTS
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "StandardCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.allowsSelection = false
        return tableView
    }()
    private lazy var plusButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(plusButtonPressed))
    
    // MARK: - DATA SOURCE
    class DataSource: UITableViewDiffableDataSource<String, String> {
        override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            let titles = ["Рене Декарт", "Стив Джобс", "Дэниел Деннет"]
            return titles[section]
        }
    }
    private var dataSource: DataSource!
    
    
    // MARK: - SEARCH CONTROLLER
    
    private lazy var searchController: UISearchController = {
        let controller = UISearchController(searchResultsController: UIViewController())
        controller.searchBar.setValue("Отменить", forKey: "cancelButtonText")
        controller.searchBar.placeholder = "Поиск цитаты"
        return controller
    }()
    
    
    // MARK: - LIFECYCLE
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViewController()
        applySnapshot(animatingDifferences: false)
    }
    
    
    // MARK: - VIEW CONTROLLER'S SETUP
    
    private func setupViewController() {
        view.backgroundColor = .systemBackground
        setupLayout()
        setupNavigationItem()
        setupDataSource()
    }
    private func setupNavigationItem() {
        navigationItem.title = "Цитаты"
        navigationItem.largeTitleDisplayMode = .never
        navigationItem.rightBarButtonItem = plusButton
        navigationItem.searchController = searchController
    }
    private func setupLayout() {
        view.addSubview(tableView)
        
        let safeArea = view.safeAreaLayoutGuide
        
        tableView.anchor(top: safeArea.topAnchor,
                         leading: safeArea.leadingAnchor,
                         bottom: safeArea.bottomAnchor,
                         trailing: safeArea.trailingAnchor)
    }
    private func setupDataSource() {
        dataSource = DataSource(tableView: tableView) { (tableView, indexPath, quote) -> UITableViewCell? in
            let cell = tableView.dequeueReusableCell(withIdentifier: "StandardCell", for: indexPath)
            cell.textLabel?.text = quote
            cell.textLabel?.numberOfLines = 0
            return cell
        }
    }
    
    // MARK: - UPDATING TABLEVIEW
    private func applySnapshot(animatingDifferences: Bool = true) {
        var snapshot = NSDiffableDataSourceSnapshot<String, String>()
        snapshot.appendSections(["Рене Декарт", "Стив Джобс", "Дэниел Деннет"])
        
        snapshot.appendItems(["Чтение хороших книг — это разговор с самыми лучшими людьми прошедших времен, и притом такой разговор, когда они сообщают нам только свои лучшие мысли", "Для того чтобы усовершенствовать ум, надо больше размышлять, чем заучивать"], toSection: "Рене Декарт")
        snapshot.appendItems(["Ваша работа заполнит большую часть жизни и единственный способ быть полностью довольным – делать то, что по-вашему является великим делом. И единственный способ делать великие дела – любить то, что вы делаете"], toSection: "Стив Джобс")
        snapshot.appendItems(["Чтобы двигать познание вперёд, теория должна поначалу быть контринтуитивной"], toSection: "Дэниел Деннет")
        
        dataSource.apply(snapshot, animatingDifferences: animatingDifferences)
    }
    
    
    // MARK: - ACTIONS
    @objc func plusButtonPressed() {
        let addEditQuoteVC = AddEditQuoteViewController(openingMode: .add)
//        addEditQuoteVC.delegate = self
        let navController = UINavigationController(rootViewController: addEditQuoteVC)
        present(navController, animated: true)
    }
}


// MARK: - TABLEVIEW'S DELEGATE
extension QuoteListViewController: UITableViewDelegate {
    
}
