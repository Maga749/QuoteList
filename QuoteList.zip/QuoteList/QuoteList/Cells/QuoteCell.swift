//
//  QuoteCell.swift
//  Quotes
//
//  Created by Магомед on 24.03.2021.
//

import UIKit

class QuoteCell: UITableViewCell {
    
    // MARK: - STATIC PROPERTIES
    static let reuseIdentifier = String(describing: QuoteCell.self)
    
    
    // MARK: - LABEL
    let quoteTextLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.preferredFont(forTextStyle: .body)
        label.numberOfLines = 0
        return label
    }()
//    let authorLabel: UILabel = {
//        let label = UILabel()
//        label.textColor = .systemGray
//        label.font = UIFont.preferredFont(forTextStyle: .footnote)
//        label.numberOfLines = 0
//        label.textAlignment = .right
//        return label
//    }()
    
    // MARK: - stack for labels
//    lazy var stackView: UIStackView = {
//        let stackView = UIStackView(arrangedSubviews: [quoteTextLabel, authorLabel])
//        stackView.axis = .vertical
//        stackView.alignment = .fill
//        stackView.spacing = 4
//        return stackView
//    }()
    
    
    // MARK: - INITIALIZATION
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupLayout()
    }
    required init?(coder: NSCoder) {
        fatalError()
    }
    
    
    // MARK: - PUBLIC SETUP METHODS
    func setup(with quote: Quote) {
        quoteTextLabel.text = quote.text
    }
    
    
    // MARK: - SETUP LAYOUT
    private func setupLayout() {
        contentView.addSubview(quoteTextLabel)
        quoteTextLabel.fillSuperviewAccordingToMargins()
    }
}
