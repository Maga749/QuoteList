//
//  UIView+Extension.swift
//  Deadline
//
//  Created by Магомед on 16.03.2021.
//

import UIKit

extension UIView {
    func anchor(top: NSLayoutYAxisAnchor? = nil, leading: NSLayoutXAxisAnchor? = nil, bottom: NSLayoutYAxisAnchor? = nil, trailing: NSLayoutXAxisAnchor? = nil, padding: NSDirectionalEdgeInsets = .init(top: 0, leading: 0, bottom: 0, trailing: 0), size: (width: CGFloat, height: CGFloat) = (0, 0)) {
        translatesAutoresizingMaskIntoConstraints = false
        
        if let top = top {
            topAnchor.constraint(equalTo: top, constant: padding.top).isActive = true
        }
        if let leading = leading {
            leadingAnchor.constraint(equalTo: leading, constant: padding.leading).isActive = true
        }
        if let bottom = bottom {
            bottomAnchor.constraint(equalTo: bottom, constant: -padding.bottom).isActive = true
        }
        if let trailing = trailing {
            trailingAnchor.constraint(equalTo: trailing, constant: -padding.trailing).isActive = true
        }
        
        if size.width != 0 {
            widthAnchor.constraint(equalToConstant: size.width).isActive = true
        }
        if size.height != 0 {
            heightAnchor.constraint(equalToConstant: size.height).isActive = true
        }
    }
    func fillSuperview(with insets: NSDirectionalEdgeInsets = .init(top: 0, leading: 0, bottom: 0, trailing: 0)) {
        translatesAutoresizingMaskIntoConstraints = false
        
        guard let superview = superview else { fatalError("View doesn't have superview to set constraints") }
        topAnchor.constraint(equalTo: superview.topAnchor, constant: insets.top).isActive = true
        leadingAnchor.constraint(equalTo: superview.leadingAnchor, constant: insets.leading).isActive = true
        bottomAnchor.constraint(equalTo: superview.bottomAnchor, constant: -insets.bottom).isActive = true
        trailingAnchor.constraint(equalTo: superview.trailingAnchor, constant: -insets.trailing).isActive = true
    }
    func fillSuperviewAccordingToMargins() {
        translatesAutoresizingMaskIntoConstraints = false
        
        guard let superview = superview else { fatalError("View doesn't have superview to set constraints") }
        topAnchor.constraint(equalTo: superview.layoutMarginsGuide.topAnchor).isActive = true
        leadingAnchor.constraint(equalTo: superview.layoutMarginsGuide.leadingAnchor).isActive = true
        bottomAnchor.constraint(equalTo: superview.layoutMarginsGuide.bottomAnchor).isActive = true
        trailingAnchor.constraint(equalTo: superview.layoutMarginsGuide.trailingAnchor).isActive = true
    }
}
